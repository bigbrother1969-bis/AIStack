---
artifact_type: foundation
target_spot: docs/00-foundation/engineering-principles.md
status: validated
transaction: KT-000004
---
## Finish the Capability

Once implementation of a capability has started, completing that capability becomes the highest engineering priority.

Lessons discovered during implementation must be recorded immediately, but improvements to tooling, packaging or the engineering factory are deferred until the capability itself is complete.
