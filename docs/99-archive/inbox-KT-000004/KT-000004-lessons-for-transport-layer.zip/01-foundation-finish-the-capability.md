---
knowledge_level: foundation
target_document: docs/00-foundation/engineering-principles.md
integration_mode: append
source: KT-000004
status: validated
---

## Finish the Capability

### Principle

Once the implementation of a capability has started, completing that capability becomes the highest engineering priority.

The capability must be completed before improving the surrounding development process, tooling, packaging, automation, or engineering infrastructure.

### Rationale

Interrupting an active implementation to improve the factory creates context switching, delays value delivery, and may leave both the capability and the tooling unfinished.

Engineering improvements should be driven by lessons learned during implementation, but they must not replace completion of the capability already in progress.

### Consequence

When weaknesses are discovered during implementation:

- record the lesson;
- complete the capability;
- improve the factory afterwards.
