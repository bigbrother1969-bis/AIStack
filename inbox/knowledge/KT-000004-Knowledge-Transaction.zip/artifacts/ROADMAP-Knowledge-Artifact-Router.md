---
artifact_type: roadmap
target_spot: docs/07-roadmap/ROADMAP.md
status: proposed
transaction: KT-000004
---
## Knowledge Artifact Router

Generalise the current ADR importer into a metadata-driven Knowledge Artifact Router supporting multiple artifact families and transport formats.
