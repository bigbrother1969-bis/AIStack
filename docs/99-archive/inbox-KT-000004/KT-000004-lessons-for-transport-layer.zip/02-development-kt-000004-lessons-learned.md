---
knowledge_level: development_practice
target_document: docs/04-development/git-transaction-engine/LESSONS-LEARNED.md
integration_mode: append
source: KT-000004
status: validated
---

# KT-000004 — Lessons Learned

## Work From an Observed Repository State

A Git Transaction must be prepared from the actual state of the repository.

Producing changes from memory or from an incomplete reconstruction creates drift, omissions, and false assumptions.

Observation precedes transformation.

## Keep the Transaction Integrable

A KT is an integration unit, not merely a small code change.

One KT must:

- carry one coherent responsibility;
- include every required contract and test adaptation;
- leave the branch in a green state;
- result in one commit.

When an API contract changes, updating the existing tests belongs to the same KT.

## Validate the Delivered Artifact

A transaction artifact must be verified before integration.

For a Git patch, the minimum checks are:

```bash
git apply --check <patch>
git diff --check
python -m pytest <impacted-tests>
```

A generated artifact is not deliverable merely because it was created. Its content and applicability must be verified.

## Prefer the Existing Transport Layer

The AIStack Transport Layer is the governed mechanism for transferring generated artifacts to the target environment.

Development sessions must use that layer rather than inventing parallel delivery mechanisms.

## Separate Delivery Problems From Capability Problems

A defect in packaging or transport does not mean that the underlying capability should be abandoned.

The delivery problem must be recorded, while implementation remains focused on completing the active capability.
