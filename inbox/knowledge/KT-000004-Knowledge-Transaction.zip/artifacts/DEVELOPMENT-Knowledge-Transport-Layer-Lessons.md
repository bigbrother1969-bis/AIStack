---
artifact_type: development
target_spot: docs/04-development/knowledge-transport-layer/LESSONS-LEARNED.md
status: validated
transaction: KT-000004
---
# KT-000004 — Knowledge Inbox Evolution

## Observation

The current Knowledge Inbox is a specialised importer (ADR only), not yet a generic Knowledge Artifact ingestion engine.

## Engineering Lesson

The Knowledge Inbox must evolve into a Knowledge Artifact Router.

Its responsibility is to transport governed knowledge rather than copy files.

## Responsibilities

- accept multiple transport formats;
- extract packaged artifacts;
- read metadata;
- resolve SPOT;
- evaluate policies;
- route to the appropriate integration workflow;
- emit an integration report;
- archive the transaction.
